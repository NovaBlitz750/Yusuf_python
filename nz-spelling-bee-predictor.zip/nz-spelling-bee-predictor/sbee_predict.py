#!/usr/bin/env python3
"""
sbee_predict.py  (v2 - ML-powered)
====================================
Predicts likely NZ Spelling Bee words by combining:

  1. A trained ML classifier (see train_model.py / model.pkl) fitted on
     ~2,500 REAL words from the Scripps National Spelling Bee's public
     "Words of the Champions" list plus the actual ANZSB winning words
     2005-2025. This gives every candidate a genuine, data-driven
     "how bee-like is this word" probability.

  2. Personalisation from YOUR OWN historical word lists (put them in
     historical/) -- repeats get flagged, and candidates that resemble
     your specific past lists (letter patterns, length, origin) get a
     bonus on top of the general model score.

If model.pkl doesn't exist yet, run `python3 train_model.py` first.

USAGE
------
    python3 train_model.py                 # train once (or after adding data)
    python3 sbee_predict.py --top 150       # generate predictions

OUTPUTS (in output/)
----------------------
    already_seen.csv   - every historical word you supplied, with year/round
    repeats.csv         - words that appeared more than once in your data
    predictions.csv     - ranked candidates: word, ml_score, personalization
                           bonus, final_score, reasons
"""

import argparse
import csv
import math
import os
import pickle
import re
import sys
from collections import Counter

import numpy as np

sys.path.insert(0, os.path.dirname(__file__))
from train_model import numeric_features  # reuse the exact same features

# ----------------------------------------------------------------------------
# Historical data loading (unchanged behaviour from v1)
# ----------------------------------------------------------------------------

VOWELS = set("aeiou")

ORIGIN_PATTERNS = {
    "greek": re.compile(r"(ph|rrh|chth|pn|ps|pt|xy|chor|chron|log|phon|phor|"
                         r"scop|therm|path|phil|graph|gram)"),
    "latin": re.compile(r"(tion$|sion$|ous$|ance$|ence$|ic$|ary$|ive$|ct|"
                         r"struct|spect|ject|duc)"),
    "french": re.compile(r"(eau|que$|ette$|oir$|eur$|ique$|age$|esque$)"),
    "germanic": re.compile(r"(sch|kn|wr|tsch|ght)"),
}

TRICKY_PATTERNS = {
    "silent_letter": re.compile(r"(kn|gn|mb$|mn|wr|gh|ps|pn|bt)"),
    "double_letter": re.compile(r"(.)\1"),
    "unusual_vowel_cluster": re.compile(r"[aeiou]{3,}"),
}


def letter_bigrams(word):
    w = word.lower()
    return [w[i:i + 2] for i in range(len(w) - 1)]


def letter_trigrams(word):
    w = word.lower()
    return [w[i:i + 3] for i in range(len(w) - 2)]


def load_historical(historical_dir):
    records = []
    if not os.path.isdir(historical_dir):
        return records
    for fname in sorted(os.listdir(historical_dir)):
        path = os.path.join(historical_dir, fname)
        if not os.path.isfile(path):
            continue
        with open(path, encoding="utf-8", errors="ignore") as f:
            content = f.read()
        lines = content.splitlines()
        looks_csv = bool(lines) and "," in lines[0]
        if looks_csv:
            f2 = open(path, encoding="utf-8", errors="ignore")
            reader = csv.DictReader(f2)
            fieldnames = [c.lower() for c in (reader.fieldnames or [])]
            if "word" in fieldnames:
                for row in reader:
                    row = {k.lower(): v for k, v in row.items()}
                    w = (row.get("word") or "").strip().lower()
                    if not w or not w.isalpha():
                        continue
                    records.append({
                        "word": w, "year": row.get("year", ""),
                        "round": row.get("round", ""), "source_file": fname,
                    })
                f2.close()
                continue
            f2.close()
        for line in lines:
            w = re.sub(r"[^a-z]", "", line.strip().lower())
            if w:
                records.append({"word": w, "year": "", "round": "",
                                 "source_file": fname})
    return records


def build_personalization_profile(historical_records):
    words = [r["word"] for r in historical_records]
    unique_words = set(words)
    if not unique_words:
        return None

    lengths = [len(w) for w in unique_words]
    mean_len = sum(lengths) / len(lengths)
    var_len = sum((l - mean_len) ** 2 for l in lengths) / len(lengths)
    std_len = math.sqrt(var_len) if var_len > 0 else 2.0

    bigram_counts = Counter()
    for w in unique_words:
        bigram_counts.update(letter_bigrams(w))
    total_bg = sum(bigram_counts.values()) or 1
    bigram_freq = {k: v / total_bg for k, v in bigram_counts.items()}

    word_counter = Counter(words)
    repeats = {w: c for w, c in word_counter.items() if c > 1}

    return {
        "mean_len": mean_len, "std_len": std_len,
        "bigram_freq": bigram_freq, "repeats": repeats,
        "seen_words": unique_words,
    }


def personalization_score(word, profile):
    """0..~1.3 bonus score for how well `word` matches the user's OWN
    historical lists specifically (on top of the general ML model)."""
    if profile is None:
        return 0.0, []
    length = len(word)
    z = (length - profile["mean_len"]) / max(profile["std_len"], 1e-6)
    length_score = math.exp(-0.5 * z * z)

    bg = letter_bigrams(word) or [word]
    bg_score = sum(profile["bigram_freq"].get(b, 0.0) for b in bg) / len(bg)

    reasons = []
    if length_score > 0.6:
        reasons.append(f"length matches YOUR historical average "
                        f"({profile['mean_len']:.1f})")
    score = 0.5 * length_score + 0.5 * (bg_score * 50)
    return score, reasons


# ----------------------------------------------------------------------------
# ML model scoring
# ----------------------------------------------------------------------------

def load_model(model_path):
    if not os.path.isfile(model_path):
        print(f"[!] No trained model found at {model_path}.")
        print(f"    Run: python3 train_model.py")
        sys.exit(1)
    with open(model_path, "rb") as f:
        return pickle.load(f)


def load_candidate_dictionary(path_or_none):
    candidates = None
    if path_or_none and os.path.isfile(path_or_none):
        with open(path_or_none, encoding="utf-8", errors="ignore") as f:
            candidates = [w.strip().lower() for w in f if w.strip()]
    else:
        for sys_path in ("/usr/share/dict/american-english",
                          "/usr/share/dict/british-english",
                          "/usr/share/dict/words"):
            if os.path.isfile(sys_path):
                with open(sys_path, encoding="utf-8", errors="ignore") as f:
                    candidates = [w.strip().lower() for w in f if w.strip()]
                break
    if not candidates:
        candidates = ["chrysanthemum", "onomatopoeia", "bureaucracy"]

    clean, seen = [], set()
    for w in candidates:
        w = w.lower()
        if re.fullmatch(r"[a-z]{5,18}", w) and w not in seen:
            seen.add(w)
            clean.append(w)
    return clean


def reason_tags(word):
    tags = []
    for name, pat in ORIGIN_PATTERNS.items():
        if pat.search(word):
            tags.append(f"origin:{name}")
    for name, pat in TRICKY_PATTERNS.items():
        if pat.search(word):
            tags.append(f"trap:{name}")
    return tags


# Common English suffixes to group by for diversity control. A raw top-N by
# score alone tends to be dominated by one or two suffix families (e.g.
# "-ous" adjectives), because the model correctly learned they're bee-
# favoured -- but a study list that's 40 "-ous" words in a row is much less
# useful than a varied one. This groups candidates by suffix/shape family
# and caps how many from any one family make the final cut.
SUFFIX_GROUPS = [
    "ous", "tion", "sion", "ology", "osis", "itis", "ance", "ence", "ic",
    "ary", "ive", "eous", "ious", "ment", "ness", "ity", "graphy", "phobia",
    "cracy", "logue", "esque",
]


def suffix_group(word):
    for suf in SUFFIX_GROUPS:
        if word.endswith(suf):
            return suf
    return "other"


def diversify(results, top_n, max_per_group_ratio=0.25):
    """Greedily pick the highest-scoring candidates while capping any single
    suffix group to at most `max_per_group_ratio` of the final list, so the
    output isn't dominated by one pattern the model happens to love."""
    cap = max(3, int(top_n * max_per_group_ratio))
    group_counts = Counter()
    chosen = []
    leftovers = []
    for r in results:
        grp = suffix_group(r[0])
        if group_counts[grp] < cap:
            chosen.append(r)
            group_counts[grp] += 1
        else:
            leftovers.append(r)
        if len(chosen) >= top_n:
            break
    # If capping left us short (small candidate pool), top up from leftovers.
    if len(chosen) < top_n:
        chosen.extend(leftovers[: top_n - len(chosen)])
    return chosen


# ----------------------------------------------------------------------------
# Main pipeline
# ----------------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser(description="NZ Spelling Bee word predictor (ML-powered)")
    ap.add_argument("--historical-dir", default="historical")
    ap.add_argument("--dictionary", default="dictionary.txt")
    ap.add_argument("--model", default=os.path.join(os.path.dirname(__file__), "model.pkl"))
    ap.add_argument("--top", type=int, default=150)
    ap.add_argument("--outdir", default="output")
    ap.add_argument("--batch-size", type=int, default=5000,
                     help="Score candidates in batches (memory control)")
    args = ap.parse_args()

    os.makedirs(args.outdir, exist_ok=True)

    model_bundle = load_model(args.model)
    pipeline = model_bundle["pipeline"]
    threshold = model_bundle.get("decision_threshold", 0.5)
    print(f"[i] Loaded model (trained on {model_bundle['n_positive']} real "
          f"bee words vs {model_bundle['n_negative']} generic words, "
          f"test ROC-AUC={model_bundle['test_auc']:.3f})")

    historical = load_historical(args.historical_dir)
    profile = build_personalization_profile(historical)
    if historical:
        print(f"[i] Loaded {len(historical)} of your own historical words "
              f"for personalisation ({len(profile['repeats'])} repeats found)")
    else:
        print(f"[i] No historical data in '{args.historical_dir}/' -- "
              f"running with the general ML model only. Add your own past "
              f"NZ lists there for personalised predictions.")

    seen_words = profile["seen_words"] if profile else set()

    # Write already_seen.csv / repeats.csv
    with open(os.path.join(args.outdir, "already_seen.csv"), "w",
              newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["word", "year", "round", "source_file"])
        for r in historical:
            w.writerow([r["word"], r["year"], r["round"], r["source_file"]])

    with open(os.path.join(args.outdir, "repeats.csv"), "w",
              newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["word", "times_seen"])
        if profile:
            for word, c in sorted(profile["repeats"].items(), key=lambda x: -x[1]):
                w.writerow([word, c])

    # Candidate scoring
    candidates = [w for w in load_candidate_dictionary(args.dictionary)
                  if w not in seen_words]
    print(f"[i] Scoring {len(candidates)} candidate words against the "
          f"trained model...")

    all_scores = np.zeros(len(candidates))
    for start in range(0, len(candidates), args.batch_size):
        batch = candidates[start:start + args.batch_size]
        probs = pipeline.predict_proba(batch)[:, 1]
        all_scores[start:start + len(batch)] = probs

    results = []
    for word, ml_prob in zip(candidates, all_scores):
        pbonus, preasons = personalization_score(word, profile)
        final = ml_prob + 0.15 * pbonus  # ML model is primary; personal data nudges it
        reasons = [f"ML model probability: {ml_prob:.3f}"] + preasons + reason_tags(word)
        results.append((word, ml_prob, pbonus, final, "; ".join(reasons)))

    results.sort(key=lambda x: -x[3])
    top = diversify(results, args.top)

    with open(os.path.join(args.outdir, "predictions.csv"), "w",
              newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["rank", "word", "ml_probability", "personalization_bonus",
                    "final_score", "reasons"])
        for i, (word, ml_prob, pbonus, final, reasons) in enumerate(top, 1):
            w.writerow([i, word, f"{ml_prob:.4f}", f"{pbonus:.4f}",
                        f"{final:.4f}", reasons])

    n_above_threshold = sum(1 for r in results if r[1] >= threshold)

    print()
    print("=" * 60)
    print("NZ SPELLING BEE PREDICTOR (ML) - RUN SUMMARY")
    print("=" * 60)
    print(f"Candidates scored         : {len(candidates)}")
    print(f"Above model's F1 threshold ({threshold:.3f}): {n_above_threshold}")
    print(f"Predictions written       : {len(top)} -> "
          f"{args.outdir}/predictions.csv")
    print()
    print("Top 20 predicted words:")
    for i, (word, ml_prob, pbonus, final, reasons) in enumerate(top[:20], 1):
        print(f"  {i:>2}. {word:<20} ml={ml_prob:.3f}  final={final:.3f}")
    print("=" * 60)


if __name__ == "__main__":
    main()
